module.exports = {
  templatePath: "/local/templates/surgut",
};
